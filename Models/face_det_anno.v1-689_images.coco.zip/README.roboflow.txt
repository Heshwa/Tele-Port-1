
face_det_anno - v1 689_images
==============================

This dataset was exported via roboflow.ai on December 24, 2021 at 4:59 AM GMT

It includes 674 images.
Face are annotated in COCO format.

The following pre-processing was applied to each image:
* Resize to 416x416 (Stretch)

The following augmentation was applied to create 3 versions of each source image:
* Random brigthness adjustment of between -25 and +25 percent


